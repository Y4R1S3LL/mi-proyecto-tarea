package ejercicio10;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */ 
import java.util.Scanner;

public class Ejercicio10 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numero;
        int suma = 0; 
        double promedio;
       
        
        for (int i = 1; i <= 10; i++) {
            System.out.print("Ingresa el numero " + i + ": ");
            numero = entrada.nextInt();
            
            suma += numero; 
        }
        
        promedio = (double) suma / 10;
       
        System.out.println("Resultados Finales ");
        System.out.println("Suma total: " + suma);
        System.out.println("Promedio: " + promedio);
        
        entrada.close();
    }
}
