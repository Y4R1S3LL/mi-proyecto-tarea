package ejercicio4;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */  
import java.util.Locale;
import java.util.Scanner;

public class Ejercicio4 {

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner entrada = new Scanner(System.in);
        
        
        entrada.useLocale(Locale.US);
        
                double nota;
        
        
        System.out.print("Por favor, ingresa la nota del estudiante: ");
        nota = entrada.nextDouble();
        
       
        if (nota >= 7.0) {
            System.out.println("Aprobado");
        } else {
            System.out.println("Reprobado");
        }
        
        
        entrada.close();
    }
}