package ejercicio8;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */  
import java.util.Scanner;

public class Ejercicio8 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String intentoContrasena;
        
        do {
            System.out.print("Por favor, ingresa la contrasenia(clave): ");
            intentoContrasena = entrada.nextLine();
            
            if (!intentoContrasena.equals("java2026")) {
                System.out.println("Clave incorrecta. Intentalo de nuevo");
            }
         
        } while (!intentoContrasena.equals("java2026")); 
        
        System.out.println("Acceso concedido.");
        
        
        entrada.close();
    }
}