package ejercicio9;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */ 
import java.util.Scanner;

public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numero;
        int resultado;
        
        System.out.print("TABLAS DE MULTIPLICAR.");
        
        System.out.print("INGRESE UN NUMERO:");
        numero = entrada.nextInt();
        
        System.out.println(" Tabla del " + numero + " (del 1 al 12) ");
        
        for (int i = 1; i <= 12; i++) {
            resultado = numero * i;
            System.out.println(numero + " x " + i + " = " + resultado);
        }
        entrada.close();
    }
}