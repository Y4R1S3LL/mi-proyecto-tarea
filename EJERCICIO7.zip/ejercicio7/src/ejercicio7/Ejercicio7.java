package ejercicio7;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */ 
import java.util.Scanner;

public class Ejercicio7 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        
        int numero;
        int contadorNumeros = 0; 
        int sumaTotal = 0;      
        
        System.out.print("Ingresa un numero entero: ");
        numero = entrada.nextInt();
      
        
        while (numero >= 0) {
            contadorNumeros++;      
            sumaTotal += numero;    
            
            System.out.print("Ingresa otro numero :");
            numero = entrada.nextInt();
        }
        
        
        System.out.println("RESULADO FINAL");
        System.out.println("Cantidad de numeros positivos ingresados: " + contadorNumeros);
        System.out.println("Suma total de los numeros: " + sumaTotal);
        
        
        entrada.close();
    }
}
