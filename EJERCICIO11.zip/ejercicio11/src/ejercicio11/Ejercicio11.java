package ejercicio11;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        
        int numero;
        int mayor = 0;
        int menor = 0;
        
       
        
        System.out.print("Ingresa el número 1: ");
        numero = entrada.nextInt();
        mayor = numero;
        menor = numero;
        
        for (int i = 2; i <= 10; i++) {
            System.out.print("Ingresa el número " + i + ": ");
            numero = entrada.nextInt();
            
            if (numero > mayor) {
                mayor = numero;
            }
            
            if (numero < menor) {
                menor = numero;
            }
        }
      
     
        System.out.println("Número mayor: " + mayor);
        System.out.println("Número menor: " + menor);
        
        entrada.close();
    }
}