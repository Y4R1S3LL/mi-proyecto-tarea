package ejercicio1;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */  
import java.util.Scanner;
import java.util.Locale;

public class Ejercicio1{

    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
       
        Scanner entrada = new Scanner(System.in);
        
        String nombre;
        int edad;
        String carrera;
        double estatura;
        System.out.print("Por favor, ingresa tu nombre completo: ");
        nombre = entrada.nextLine();
        
        System.out.print("Ingresa tu edad: ");
        edad = entrada.nextInt();
        
        
        entrada.nextLine(); 
        
        System.out.print("Que carrera estas cursando?: ");
        carrera = entrada.nextLine();
        
        System.out.print("Ingresa tu estatura en metros (ejemplo: 1.75): ");
        estatura = entrada.nextDouble();
        
        
        System.out.println("Datos Registrados");
        System.out.println("Nombre: " + nombre);
        System.out.println("Edad: " + edad );
        System.out.println("Carrera: " + carrera);
        System.out.println("Estatura: " + estatura + " m");
        
        
        entrada.close();
    }
}