package ejercicio3;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */  
import java.util.Scanner;

public class Ejercicio3 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        int edad;
        
        System.out.print("Por favor, ingresa tu edad: ");
        edad = entrada.nextInt();
         
        if (edad >= 18) {
            System.out.println("Es mayor de edad.");
        }
        
        entrada.close();
    }
}