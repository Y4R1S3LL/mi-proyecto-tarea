package ejercicio11;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */
import java.util.Scanner;

public class Ejercicio11 {
    public static void main(String[] args) {
       
        Scanner entrada = new Scanner(System.in);
        
        int numero;
        int mayor = 0;
        int menor = 0;
        
       
        
        System.out.print("Ingresa el numero 1: ");
        numero = entrada.nextInt();
        mayor = numero;
        menor = numero;
        
        for (int i = 2; i <= 10; i++) {
            System.out.print("Ingresa el numero " + (i+1) + ": ");
            numero = entrada.nextInt();
            
            if (numero > mayor) {
                mayor = numero;
            }
            
            if (numero < menor) {
                menor = numero;
            }
        }
     
        System.out.println("Numero mayor: " + mayor);
        System.out.println("Numero menor: " + menor);
        
        entrada.close();
    }
}