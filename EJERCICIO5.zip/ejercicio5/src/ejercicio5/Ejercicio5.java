package ejercicio5;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */  
import java.util.Scanner;

public class Ejercicio5 {

    public static void main(String[] args) {
      
       
        Scanner entrada = new Scanner(System.in);
        
        
        double calificacion;
        
        
        System.out.print("Por favor, ingresa una calificacion (0 - 10): ");
        String entradaTexto = entrada.nextLine();
        
       
        calificacion = Double.parseDouble(entradaTexto);
        
        
        System.out.println("Resultado de la Evaluacion ");
        if (calificacion >= 9.0 && calificacion <= 10.0) {
            System.out.println("Excelente");
        } else if (calificacion >= 8.0 && calificacion < 9.0) {
            System.out.println("Muy Bueno");
        } else if (calificacion >= 7.0 && calificacion < 8.0) {
            System.out.println("Bueno");
        } else if (calificacion >= 5.0 && calificacion < 7.0) {
            System.out.println("Regular");
        } else if (calificacion >= 0.0 && calificacion < 5.0) {
            System.out.println("Deficiente");
        } else {
            System.out.println("Error: La calificacion ingresada esta fuera del rango permitido (0 - 10).");
        }
        
        entrada.close();
    }
}