package ejercicio6;

import java.util.Scanner;
/**
 * @author [Yuleysi Yarisell Paguay Chuncho]
 */  
public class Ejercicio6 {

    public static void main(String[] args) {
        
        Scanner entrada = new Scanner(System.in);
        
        
        int numeroDia;
        
        
        System.out.print("Por favor, ingresa un numero entre 1 y 7: ");
        numeroDia = entrada.nextInt();
        
        System.out.print("El dia correspondiente es: ");
        switch (numeroDia) {
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miercoles");
                break;
            case 4:
                System.out.println("Jueves");
                break;
            case 5:
                System.out.println("Viernes");
                break;
            case 6:
                System.out.println("Sabado");
                break;
            case 7:
                System.out.println("Domingo");
                break;
            default:
                System.out.println("Error: El numero ingresado no esta entre 1 y 7.");
                break;
        }
        
        entrada.close();
    }
}